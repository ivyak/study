import random

# ------------------------------
# 課題1用の関数
# ------------------------------

# n次正方行列作成
def make_square_matrix(n: int):
  return [[random.random() for _ in range(n)] for _ in range(n)]

# n次元ベクトル作成
def make_vector(n: int):
  return [random.random() for _ in range(n)]

# 拡大行列の作成
def make_expansion_matrix(A: list[list[float]], b: list[float]):
  return [A[i] + [b[i]] for i in range(len(A))]

# 行列(正方行列に限らない)を行基本変形で階段行列にする
def make_ref(A: list[list[float]]):
  for i in range(len(A)): # len(A)は行数
    # ピボットの選択
    pivot_row: int = i

    # ピボットとして 0 に近いものを選ぶと，後の演算で桁落ちが起こったり
    # 情報落ちのため精度が悪化したりする可能性があるため，絶対値が最大のものを選ぶ
    # (同時にピボットが0になるのを回避)
    for j in range(i + 1, len(A)):
      if abs(A[j][i]) > abs(A[pivot_row][i]):
        # ピボット行を更新
        pivot_row = j

    # ピボット行を現在の行と入れ替える
    A[i], A[pivot_row] = A[pivot_row], A[i]

    # ピボット行を使って他の行を消去
    for j in range(i + 1, len(A)):
      if A[j][i] != 0:
        factor = A[j][i] / A[i][i]
        for k in range(i, len(A[0])):
          A[j][k] -= factor * A[i][k]
  return A

# 階段行列から漸化式で解を求める
# (Aは拡大行列であることを前提としている)
def back_substitution(A: list[list[float]]):
  n: int = len(A)
  x: list[float] = [0] * n

  for i in range(n - 1, -1, -1):
    sum_ax: float = sum(A[i][j] * x[j] for j in range(i + 1, n))
    x[i] = (A[i][-1] - sum_ax) / A[i][i]
  return x

def Gaussian_elimination(A: list[list[float]], b: list[float]):
  # 拡大行列を作成
  A_expanded: list[list[float]] = make_expansion_matrix(A, b)

  # 階段行列に変換
  A_ref: list[list[float]] = make_ref(A_expanded)

  # 後退代入で解を求める
  x: list[float] = back_substitution(A_ref)
  return x

# 無限大ノルムを求める
def infinity_norm(vector: list[float]):
  return max(abs(x) for x in vector)

# 相対誤差を求める
def relative_error(x_true, x_approx: list[float]):
  return infinity_norm([x_true[i] - x_approx[i] for i in range(len(x_true))]) / infinity_norm(x_true)

# 行列×ベクトルを求める
def matrix_vector_product(A: list[list[float]], x: list[float]):
  return [sum(A[i][j] * x[j] for j in range(len(x))) for i in range(len(A))]

# 残差ノルムを求める
def residual_norm_Gaussian(A: list[list[float]], x: list[float], b: list[float]):
  Ax: list[float] = matrix_vector_product(A, x)
  return infinity_norm([Ax[i] - b[i] for i in range(len(b))])

# ------------------------------
# 課題2用の関数
# ------------------------------

# 正方行列をLU分解
def LU_decomposition(A: list[list[float]]):
  n: int = len(A)
  U: list[list[float]] = [row[:] for row in A]
  L: list[list[float]] = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
  P_pi: list[list[float]] = [[1 if i == j else 0 for j in range(n)] for i in range(n)]

  for i in range(n):
    pivot_row: int = i

    for j in range(i + 1, n):
      if abs(U[j][i]) > abs(U[pivot_row][i]):
        # ピボット行を更新
        pivot_row = j
    if pivot_row != i:
      U[i], U[pivot_row] = U[pivot_row], U[i]
      # Lでは計算済みの列だけを交換し、対角成分は動かさない
      L[i][:i], L[pivot_row][:i] = L[pivot_row][:i], L[i][:i]
      P_pi[i], P_pi[pivot_row] = P_pi[pivot_row], P_pi[i]

    for j in range(i + 1, n):
      factor: float = U[j][i] / U[i][i]
      L[j][i] = factor
      U[j][i] = 0
      for k in range(i + 1, n):
        U[j][k] -= factor * U[i][k]

  return L, U, P_pi

def forward_substitution_LU(L: list[list[float]], P_pi: list[list[float]], b: list[float]):
  n: int = len(L)
  Pb: list[float] = matrix_vector_product(P_pi, b)
  y: list[float] = [0] * n

  for i in range(n):
    sum_ly: float = sum(L[i][j] * y[j] for j in range(i))
    y[i] = Pb[i] - sum_ly
  return y

def back_substitution_LU(U: list[list[float]], y: list[float]):
  n: int = len(U)
  x: list[float] = [0] * n

  for i in range(n - 1, -1, -1):
    sum_ux: float = sum(U[i][j] * x[j] for j in range(i + 1, n))
    x[i] = (y[i] - sum_ux) / U[i][i]
  return x

def LU_solve(A: list[list[float]], b: list[float]):
  L, U, P_pi = LU_decomposition(A)
  y: list[float] = forward_substitution_LU(L, P_pi, b)
  x: list[float] = back_substitution_LU(U, y)
  return x

# ------------------------------
# 課題4用の関数
# ------------------------------

def power_method(A: list[list[float]], tol: float = 1e-6, x0=None, residual_tol=None):
  x: list[float] = list(x0) if x0 is not None else [random.random() for _ in range(len(A))]
  mu: float = 0.0
  iteration_num: int = 0
  while True:
    y: list[float] = matrix_vector_product(A, x)
    iteration_num += 1

    mu_prev: float = mu
    i = max(range(len(x)), key=lambda j: abs(x[j]))
    mu: float = y[i] / x[i]

    if abs(mu - mu_prev) / abs(mu) < tol:
      if residual_tol is None or residual_norm_PowerMethod(mu, x, A) <= residual_tol:
        break

    y_norm = infinity_norm(y)
    x: list[float] = [y[i] / y_norm for i in range(len(y))]
  return mu, x, iteration_num


def residual_norm_PowerMethod(eigenvalue: float, eigenvector: list[float], A: list[list[float]]):
  Av: list[float] = matrix_vector_product(A, eigenvector)
  return infinity_norm([eigenvalue * eigenvector[i] - Av[i] for i in range(len(eigenvector))])

def eigenvalue_error(true_value: float, computed_value: float):
  return abs(true_value - computed_value) / abs(true_value)

def eigenvector_error(true_vector, eigenvector: list[float]):
    # 条件(1)
    true_vector_normalized: list[float] = [x / infinity_norm(true_vector) for x in true_vector]
    eigenvector_normalized: list[float] = [x / infinity_norm(eigenvector) for x in eigenvector]

    # 条件(2)
    for k in range(len(true_vector)):
      if true_vector_normalized[k] != 0 and eigenvector_normalized[k] != 0:
        break
    else:
        raise ValueError("共通の非零成分がありません")

    if true_vector_normalized[k] < 0:
      true_vector_normalized = [-x for x in true_vector_normalized]
    if eigenvector_normalized[k] < 0:
      eigenvector_normalized = [-x for x in eigenvector_normalized]

    return relative_error(true_vector_normalized, eigenvector_normalized)

# ------------------------------
# 課題5用の関数
# ------------------------------


def inverse_iteration(A: list[list[float]], sigma: float, x0=None, residual_tol=None):
  n: int = len(A)
  x: list[float] = list(x0) if x0 is not None else [random.random() for _ in range(n)]
  B = [[A[i][j] - (sigma if i == j else 0) for j in range(n)] for i in range(n)]
  L, U, P_pi = LU_decomposition(B)

  mu: float = 0.0
  iteration_num: int = 0

  while True:
    # (1) (A - sigma I)y = x 
    z = forward_substitution_LU(L, P_pi, x)
    y = back_substitution_LU(U, z)
    iteration_num += 1

    # (2) 
    mu_prev = mu
    i = max(range(n), key=lambda j: abs(x[j]))
    mu = y[i] / x[i]

    # (3) 
    if abs(mu - mu_prev) < 1e-6 * abs(mu):
      if residual_tol is None or residual_norm_PowerMethod(1 / mu + sigma, x, A) <= residual_tol:
        break

    # (4) 
    y_norm = infinity_norm(y)
    x = [y[i] / y_norm for i in range(n)]

  return 1 / mu + sigma, x, iteration_num

import numpy as np
from scipy.linalg import lu_factor, lu_solve


def power_method_numpy(A, x0=None, residual_tol=1e-8, max_iter=10000):

  A = np.asarray(A, dtype=float)
  x = np.array(x0 if x0 is not None else make_vector(len(A)), dtype=float)
  x /= np.max(np.abs(x))

  for iteration_num in range(1, max_iter + 1):
    y = A @ x
    i = np.argmax(np.abs(x))
    eigenvalue = y[i] / x[i]

    if np.max(np.abs(y - eigenvalue * x)) <= residual_tol:
      return eigenvalue, x, iteration_num
    x = y / np.max(np.abs(y))

  raise RuntimeError("最大反復回数までにべき乗法が収束しませんでした")


def inverse_iteration_numpy(A, sigma, x0=None, residual_tol=1e-8, max_iter=10000, Ax0=None):
  A = np.asarray(A, dtype=float)

  x = np.array(x0 if x0 is not None else make_vector(len(A)), dtype=float)
  x_norm = np.max(np.abs(x))
  x /= x_norm

  Ax = A @ x if Ax0 is None else np.asarray(Ax0, dtype=float) / x_norm

  if np.max(np.abs(Ax - sigma * x)) <= residual_tol:
    return sigma, x, 0
  
  return _inverse_iteration_scipy(A, sigma, x, residual_tol, max_iter)


def _inverse_iteration_scipy(A, sigma, x, residual_tol, max_iter=10000):
  shifted_A = A.copy(order="F")
  shifted_A.flat[::len(A) + 1] -= sigma

  lu, piv = lu_factor(shifted_A, overwrite_a=True, check_finite=False)

  for iteration_num in range(1, max_iter + 1):
    x = lu_solve((lu, piv), x, overwrite_b=True, check_finite=False)
    x /= np.max(np.abs(x))

    Ax = A @ x
    eigenvalue = (x @ Ax) / (x @ x)
    if np.max(np.abs(Ax - eigenvalue * x)) <= residual_tol:
      return eigenvalue, x, iteration_num

  raise RuntimeError("最大反復回数までに逆反復法が収束しませんでした")


def power_inverse_numpy(A, x0=None, power_iterations=3, residual_tol=1e-8):
  A = np.asarray(A, dtype=float)
  x = np.array(x0 if x0 is not None else make_vector(len(A)), dtype=float)
  x /= np.max(np.abs(x))

  for step in range(power_iterations):
    x = A @ x

    if (step + 1) % 3 == 0 or step + 1 == power_iterations:
      x /= np.max(np.abs(x))

  Ax = A @ x
  sigma = (x @ Ax) / (x @ x)
  if np.max(np.abs(Ax - sigma * x)) <= residual_tol:
    return sigma, x, power_iterations
  eigenvalue, eigenvector, inverse_iter = _inverse_iteration_scipy(
      A, sigma, x, residual_tol,
  )
  return eigenvalue, eigenvector, power_iterations + inverse_iter
